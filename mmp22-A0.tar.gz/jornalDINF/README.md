# organização

- fazer fila de BN e de informes